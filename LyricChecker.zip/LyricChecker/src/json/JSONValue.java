package json;

// Any value returned by the JSONParser
// must extend this class. Used to
// cope with JavaScript's dynamic typing.
public abstract class JSONValue {
}
